# Upload / Update Guide — Deep-Learning-for-NLP

**Target repository:** https://github.com/g25ait2138-collab/Deep-Learning-for-NLP

This deliverable was prepared and locally tested, but automated GitHub editing was **denied with HTTP 403** (`Resource not accessible by integration`). Consequently the remote repository was **not changed**. To publish the improved work, use your own authenticated GitHub account (with write access) and the instructions below.

## Recommended: GitHub Desktop (Windows)

1. Download and extract the `Deep-Learning-for-NLP_GitHub_Ready.zip` package.
2. In **GitHub Desktop**, choose **File → Clone repository** and clone `g25ait2138-collab/Deep-Learning-for-NLP`.
3. Create a new branch, for example `review/flowers-reproducible-cleanup`.
4. Copy **the contents** of the extracted folder into the local cloned repository, preserving paths (`src/`, `tests/`, `notebooks/`, `.github/`, `docs/`, `archive/`, `tools/`).
5. The new `README.md` replaces the old short README. Do **not** delete current root files `flowers.ipynb`, `flowers-checkpoint.ipynb`, or `12.png` yet. The new recommended runnable notebook is `notebooks/flowers_classification.ipynb`.
6. Review changed files in GitHub Desktop; commit with message `Add reproducible flowers notebook, tests and documentation`.
7. **Publish branch** and **Create Pull Request**. Confirm tests pass. Merge to `main` after reviewing.

## Alternative: Git CLI

After cloning the repository and copying the package contents into the clone:

```bash
git switch -c review/flowers-reproducible-cleanup
git status
git add README.md .gitignore requirements.txt PACKAGE_MANIFEST.md GITHUB_UPLOAD_GUIDE.md .github src tests notebooks docs archive tools
git commit -m "Add reproducible flowers classifier, tests and documentation"
git push --set-upstream origin review/flowers-reproducible-cleanup
```

Open a pull request into `main` on GitHub. Your original root notebooks remain untouched.

## Verify before publishing

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Open `notebooks/flowers_classification.ipynb` in Colab and choose `Runtime → Run all` to double-check output.

## Notes

- The attached Hindi PDF is preserved under `docs/` as source material; it was not modified.
- The video transcription notebook is an optional separate utility and was not run without a video input.
- Archived original notebooks retain their historical output and should not be presented as freshly executed.
- Keep `.ipynb_checkpoints`, credentials, large videos and generated transcripts out of version control.

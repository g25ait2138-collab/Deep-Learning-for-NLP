# Package Manifest

This archive preserves original uploaded materials under `archive/`, supplies reviewed code, tests, an executed notebook and project documentation.

- `.github/workflows/python-tests.yml` (396 bytes)
- `GITHUB_UPLOAD_GUIDE.md` (2,627 bytes)
- `PACKAGE_MANIFEST.md` (1,005 bytes)
- `README.md` (3,911 bytes)
- `VERIFICATION_REPORT.md` (2,004 bytes)
- `archive/README_original_uploaded.md` (10 bytes)
- `archive/README_previous_github.md` (201 bytes)
- `archive/flowers_checkpoint_original.ipynb` (54,149 bytes)
- `archive/flowers_original.ipynb` (97,810 bytes)
- `docs/Flowers_Classification_Using_Artificial_Neural_Network.pdf` (1,232,509 bytes)
- `docs/gitignore_additions.txt` (185 bytes)
- `docs/technical_review.md` (3,365 bytes)
- `notebooks/flowers_classification.ipynb` (116,809 bytes)
- `requirements.txt` (34 bytes)
- `src/__init__.py` (38 bytes)
- `src/flower_classifier.py` (2,635 bytes)
- `tests/test_flower_classifier.py` (1,883 bytes)
- `tools/video_transcription_colab.ipynb` (4,030 bytes)

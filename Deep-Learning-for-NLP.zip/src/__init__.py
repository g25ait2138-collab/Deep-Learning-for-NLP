"""Simple educational classifiers."""
